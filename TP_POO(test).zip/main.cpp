// POO 23/24
// Biblioteca para manipulação da consola
//
// Uso fora do âmbito de POO -> Perguntar primeiro aos professores
// Depósito em repositórios públicos -> Perguntar primeiro aos professores
//
// Pode ser aumentada com funcionalidades novas (desde que funcionem)

#include <string>
#include <iostream>
#include <sstream>
#include <iomanip>
#include "curses.h"
#include "zone.h"
#include "home.h"
#include "processor.h"

// inicialização das static int
int proc::processor::pID = 0;


int main() {

    Home Home(3, 3);

    Home.addZone(1, 2, 1, "quarto");
    Home.addZone(0, 2, 0, "sala");
    Home.addZone(2, 1, 2, "wc");

    Home.showHome();
    proc::processor a;
    proc::processor b;
    proc::processor c;
    proc::processor d;
    std::cout << "processador a com ID: " << a.id << std::endl;
    std::cout << "processador b com ID: " << b.id << std::endl;
    std::cout << "processador c com ID: " << c.id << std::endl;
    std::cout << "processador d com ID: " << d.id << std::endl;

    return 0;
}