//
// Created by ajord on 16/11/2023.
//

#include "processor.h"
#include <sstream>


namespace proc {

    processor::processor(){
        processor::id = ++pID; // começa no '1' e não no '0', já que as static estão a ser inicializadas a zero
        processor::devID = "p";
        processor::devID += std::to_string(id);
    }

    processor::~processor() {

    }
} // proc