//
// Created by ajord on 16/11/2023.
//

#ifndef TPPOO_PROCESSOR_H
#define TPPOO_PROCESSOR_H
#include <string>

namespace proc {

    class processor {
    public:
        int id;
        std::string devID;
        processor();

        virtual ~processor();

    private:
        static int pID;

    };// proc

#endif

}//TPPOO_PROCESSOR_H